import Navbarshow from "@/components/Navbar";
import React from "react";

function Header() {
  return <Navbarshow About={"About"} Home={"Home"} Login="Login" />;
}

export default Header;
