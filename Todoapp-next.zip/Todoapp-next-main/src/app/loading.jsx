import "../scss/loading.scss";
function Loading() {
  return <div className="spinner"></div>;
}
export default Loading;
