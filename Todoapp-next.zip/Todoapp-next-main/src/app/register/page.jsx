import React from "react";
import Registerpage from "./registerpage";

function Register() {
  return <Registerpage />;
}

export default Register;
