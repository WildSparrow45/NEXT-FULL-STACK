import React from "react";
import Loginpage from "./loginpage";

function Login() {
  return <Loginpage />;
}

export default Login;
