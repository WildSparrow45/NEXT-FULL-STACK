import "@/scss/home.scss";
import Home from "./home/page";
function Mainpage() {
  return (
    <div>
      <Home />
    </div>
  );
}

export default Mainpage;
